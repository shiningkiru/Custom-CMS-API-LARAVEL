<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Pages extends Model
{
    protected $fillable = ['title', 'slug', 'description', 'metaTitle', 'metaDescription', 'canonicalUrl'];


    /**
     * Get the comments for the blog post.
     */
    public function page_sections()
    {
        return $this->hasMany('App\PageSection','pages_id');
    }
}
